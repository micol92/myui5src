sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("hkmc.poc.ns.ui5demo.controller.App", {
		onInit: function () {

		}
	});
});